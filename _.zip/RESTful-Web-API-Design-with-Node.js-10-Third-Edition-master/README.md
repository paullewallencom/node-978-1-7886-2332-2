## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/restful-web-api-design-with-node-js-10-third-edition/9781788623322)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1788623320).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# RESTful Web API Design with Node.js 10 - Third Edition
This is the code repository for [RESTful Web API Design with Node.js 10 - Third Edition](https://www.packtpub.com/web-development/restful-web-api-design-nodejs-10-third-edition?utm_source=github&utm_medium=repository&utm_campaign=9781788623322), published by [Packt](https://www.packtpub.com/?utm_source=github). It contains all the supporting project files necessary to work through the book from start to finish.
## About the Book
This book targets developers who want to enrich their development skills by learning how
to develop scalable, server-side, RESTful applications based on the Node.js platform. You
also need to be aware of HTTP communication concepts and should have a working
knowledge of the JavaScript language. Keep in mind that this is not a book that will teach
you how to program in JavaScript. Knowledge of REST will be an added advantage but is
definitely not a necessity.
## Instructions and Navigation
All of the code is organized into folders. Each folder starts with a number followed by the application name. For example, Chapter02.



The code will look like the following:
```
router.get('/v1/item/:itemId', function(request, response, next) {
 console.log(request.url + ' : querying for ' + request.params.itemId);
 catalogV1.findItemById(request.params.itemId, response);
});
router.get('/v1/:categoryId', function(request, response, next) {
 console.log(request.url + ' : querying for ' +
request.params.categoryId);
 catalogV1.findItemsByCategory(request.params.categoryId, response);
});
```

## Related Products
* [Mastering Node.js - Second Edition](https://www.packtpub.com/web-development/mastering-nodejs-second-edition?utm_source=github&utm_medium=repository&utm_campaign=9781785888960)

* [Learning Node.js Development](https://www.packtpub.com/web-development/learning-nodejs-development?utm_source=github&utm_medium=repository&utm_campaign=9781788395540)
